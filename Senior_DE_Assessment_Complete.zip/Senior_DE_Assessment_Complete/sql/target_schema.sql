/*
Senior Data Engineer Assessment
Target schema for SQL Server / Azure SQL.
Recommended pattern: load dbo.stg_fact_sales from Spark, then MERGE into dbo.fact_sales.
*/

IF OBJECT_ID('dbo.fact_sales','U') IS NULL
BEGIN
    CREATE TABLE dbo.fact_sales (
        SalesSK BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_fact_sales PRIMARY KEY,
        OrderID VARCHAR(50) NOT NULL,
        ProductID VARCHAR(50) NOT NULL,
        ProductName NVARCHAR(200) NULL,
        Category NVARCHAR(100) NULL,
        SaleAmount DECIMAL(18,2) NOT NULL,
        Currency CHAR(3) NOT NULL,
        FXRateToUSD DECIMAL(18,8) NOT NULL,
        SaleAmountUSD DECIMAL(18,2) NOT NULL,
        Discount DECIMAL(8,4) NOT NULL CONSTRAINT DF_fact_sales_Discount DEFAULT (0),
        NetAmountUSD DECIMAL(18,2) NOT NULL,
        OrderDate DATE NOT NULL,
        Region NVARCHAR(50) NOT NULL,
        CustomerID VARCHAR(100) NOT NULL,
        ProcessedAtUTC DATETIME2(3) NOT NULL,
        RunID UNIQUEIDENTIFIER NOT NULL,
        RateSource VARCHAR(20) NULL
    );
    CREATE UNIQUE INDEX UX_fact_sales_OrderID ON dbo.fact_sales(OrderID);
    CREATE INDEX IX_fact_sales_OrderDate ON dbo.fact_sales(OrderDate);
    CREATE INDEX IX_fact_sales_ProductDate ON dbo.fact_sales(ProductID, OrderDate);
    CREATE INDEX IX_fact_sales_CustomerDate ON dbo.fact_sales(CustomerID, OrderDate);
    CREATE INDEX IX_fact_sales_RegionDate ON dbo.fact_sales(Region, OrderDate);
END;
GO

IF OBJECT_ID('dbo.etl_rejected_records','U') IS NULL
BEGIN
    CREATE TABLE dbo.etl_rejected_records (
        RejectedSK BIGINT IDENTITY(1,1) PRIMARY KEY,
        RunID UNIQUEIDENTIFIER NOT NULL,
        RejectedAtUTC DATETIME2(3) NOT NULL,
        SourceFile NVARCHAR(500) NULL,
        OrderID VARCHAR(50) NULL,
        ProductID VARCHAR(50) NULL,
        SaleAmount NVARCHAR(100) NULL,
        OrderDate NVARCHAR(100) NULL,
        Region NVARCHAR(100) NULL,
        CustomerID VARCHAR(100) NULL,
        Discount NVARCHAR(100) NULL,
        Currency CHAR(3) NULL,
        RejectionReason NVARCHAR(500) NOT NULL
    );
    CREATE INDEX IX_etl_rejected_RunID ON dbo.etl_rejected_records(RunID);
END;
GO

IF OBJECT_ID('dbo.etl_error_log','U') IS NULL
BEGIN
    CREATE TABLE dbo.etl_error_log (
        ErrorLogSK BIGINT IDENTITY(1,1) PRIMARY KEY,
        RunID UNIQUEIDENTIFIER NOT NULL,
        ErrorTimestampUTC DATETIME2(3) NOT NULL,
        ErrorType VARCHAR(50) NOT NULL,
        Severity VARCHAR(20) NOT NULL,
        OrderID VARCHAR(50) NULL,
        RecordDetails NVARCHAR(MAX) NULL,
        ErrorMessage NVARCHAR(2000) NULL,
        StackTrace NVARCHAR(MAX) NULL
    );
    CREATE INDEX IX_etl_error_RunID_Time ON dbo.etl_error_log(RunID, ErrorTimestampUTC);
END;
GO

IF OBJECT_ID('dbo.etl_currency_conversion_log','U') IS NULL
BEGIN
    CREATE TABLE dbo.etl_currency_conversion_log (
        ConversionLogSK BIGINT IDENTITY(1,1) PRIMARY KEY,
        RunID UNIQUEIDENTIFIER NOT NULL,
        ConversionTimestampUTC DATETIME2(3) NOT NULL,
        OrderID VARCHAR(50) NULL,
        Currency CHAR(3) NOT NULL,
        RateToUSD DECIMAL(18,8) NOT NULL,
        RateSource VARCHAR(20) NOT NULL,
        RateTimestampUTC NVARCHAR(50) NULL,
        APIError NVARCHAR(2000) NULL
    );
    CREATE INDEX IX_fx_log_RunID_Time ON dbo.etl_currency_conversion_log(RunID, ConversionTimestampUTC);
END;
GO

IF OBJECT_ID('dbo.etl_run_log','U') IS NULL
BEGIN
    CREATE TABLE dbo.etl_run_log (
        RunID UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_etl_run_log PRIMARY KEY,
        StartTimeUTC DATETIME2(3) NOT NULL,
        EndTimeUTC DATETIME2(3) NULL,
        SourceRowCount BIGINT NULL,
        DuplicateRowCount BIGINT NULL,
        ValidRowCount BIGINT NULL,
        RejectedRowCount BIGINT NULL,
        RejectionRate DECIMAL(9,6) NULL,
        FXFallbackCount BIGINT NULL,
        Status VARCHAR(20) NOT NULL,
        FailureReason NVARCHAR(2000) NULL
    );
END;
GO

/* Staging table shape. In production, load this from Spark with the same column definitions. */
IF OBJECT_ID('dbo.stg_fact_sales','U') IS NULL
BEGIN
    CREATE TABLE dbo.stg_fact_sales (
        OrderID VARCHAR(50) NOT NULL,
        ProductID VARCHAR(50) NOT NULL,
        ProductName NVARCHAR(200) NULL,
        Category NVARCHAR(100) NULL,
        SaleAmount DECIMAL(18,2) NOT NULL,
        Currency CHAR(3) NOT NULL,
        FXRateToUSD DECIMAL(18,8) NOT NULL,
        SaleAmountUSD DECIMAL(18,2) NOT NULL,
        Discount DECIMAL(8,4) NOT NULL,
        NetAmountUSD DECIMAL(18,2) NOT NULL,
        OrderDate DATE NOT NULL,
        Region NVARCHAR(50) NOT NULL,
        CustomerID VARCHAR(100) NOT NULL,
        ProcessedAtUTC DATETIME2(3) NOT NULL,
        RunID UNIQUEIDENTIFIER NOT NULL,
        RateSource VARCHAR(20) NULL
    );
END;
GO

/* Idempotent upsert: business key is OrderID for this assessment. */
MERGE dbo.fact_sales AS tgt
USING dbo.stg_fact_sales AS src
ON tgt.OrderID = src.OrderID
WHEN MATCHED THEN UPDATE SET
    ProductID=src.ProductID, ProductName=src.ProductName, Category=src.Category,
    SaleAmount=src.SaleAmount, Currency=src.Currency, FXRateToUSD=src.FXRateToUSD,
    SaleAmountUSD=src.SaleAmountUSD, Discount=src.Discount, NetAmountUSD=src.NetAmountUSD,
    OrderDate=src.OrderDate, Region=src.Region, CustomerID=src.CustomerID,
    ProcessedAtUTC=src.ProcessedAtUTC, RunID=src.RunID, RateSource=src.RateSource
WHEN NOT MATCHED THEN INSERT (
    OrderID,ProductID,ProductName,Category,SaleAmount,Currency,FXRateToUSD,
    SaleAmountUSD,Discount,NetAmountUSD,OrderDate,Region,CustomerID,
    ProcessedAtUTC,RunID,RateSource
) VALUES (
    src.OrderID,src.ProductID,src.ProductName,src.Category,src.SaleAmount,src.Currency,src.FXRateToUSD,
    src.SaleAmountUSD,src.Discount,src.NetAmountUSD,src.OrderDate,src.Region,src.CustomerID,
    src.ProcessedAtUTC,src.RunID,src.RateSource
);
GO
